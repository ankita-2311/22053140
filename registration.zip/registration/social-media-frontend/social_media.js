import { useEffect, useState } from "react";

export default function Home() { const [users, setUsers] = useState([]); const [trendingPosts, setTrendingPosts] = useState([]); const [feed, setFeed] = useState([]);

useEffect(() => { fetch("http://localhost:5000/users") // Replace with your API endpoint .then((res) => res.json()) .then((data) => setUsers(data));

fetch("http://localhost:5000/posts?type=popular") // Fetch trending posts
  .then((res) => res.json())
  .then((data) => setTrendingPosts(data));

fetch("http://localhost:5000/posts?type=latest") // Fetch latest feed
  .then((res) => res.json())
  .then((data) => setFeed(data));

}, []);

return ( <div className="p-6 bg-gray-900 text-white min-h-screen"> <h1 className="text-3xl font-bold">Social Media Analytics</h1>

<section>
    <h2 className="text-xl font-semibold mt-4">Top Users</h2>
    <ul>
      {users.map((user, index) => (
        <li key={index} className="p-2 bg-gray-800 mt-2 rounded">
          {user.name} - {user.postCount} posts
        </li>
      ))}
    </ul>
  </section>
  
  <section>
    <h2 className="text-xl font-semibold mt-4">Trending Posts</h2>
    <ul>
      {trendingPosts.map((post) => (
        <li key={post.id} className="p-2 bg-gray-800 mt-2 rounded">
          {post.content} - {post.commentCount} comments
        </li>
      ))}
    </ul>
  </section>
  
  <section>
    <h2 className="text-xl font-semibold mt-4">Live Feed</h2>
    <ul>
      {feed.map((post) => (
        <li key={post.id} className="p-2 bg-gray-800 mt-2 rounded">
          {post.content}
        </li>
      ))}
    </ul>
  </section>
</div>

); }