const axios = require("axios");

async function register() {
  try {
    const response = await axios.post("http://20.244.56.144/evaluation-service/register", {
      email: "22053140@kiit.ac.in",
      name: "Ankita Kumari",
      mobileNo: "6394168049",
      githubUsername: "ankita-2311",
      rollNo: "22053140",
      collegeName: "Kalinga Institute of Industrial Technology",
      accessCode: "nwpwrZ"
    });

    console.log("Registration Successful:", response.data);
  } catch (error) {
    console.error("Registration Failed:", error.response ? error.response.data : error.message);
  }
}

register();