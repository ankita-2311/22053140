import React, { useEffect, useState } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/social-media-data").then((res) => {
      setData(res.data);
    });
  }, []);

  return (
    <div>
      <h1>Social Media Analytics</h1>
      <Bar data={{
        labels: data.map(d => d.platform),
        datasets: [{ label: "Engagement", data: data.map(d => d.engagement) }]
      }} />
    </div>
  );
}

export default App;