const { fetchUsers, fetchUserPosts } = require("../services/apiService");

async function getTopUsers(req, res) {  // ✅ Add async here
  try {
    const users = await fetchUsers();  // ✅ Now await works
    let userPostCounts = [];

    for (let userId in users) {
      const posts = await fetchUserPosts(userId);
      userPostCounts.push({ id: userId, name: users[userId], postCount: posts.length });
    }

    userPostCounts.sort((a, b) => b.postCount - a.postCount);
    res.json(userPostCounts.slice(0, 5));
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
}

module.exports = { getTopUsers };