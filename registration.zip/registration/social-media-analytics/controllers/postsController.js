const { fetchUsers, fetchUserPosts, fetchPostComments } = require("../services/apiService");

async function getTopOrLatestPosts(req, res) {
  try {
    const { type } = req.query;
    let allPosts = [];

    const users = await fetchUsers();
    for (let userId in users) {
      const posts = await fetchUserPosts(userId);
      allPosts = allPosts.concat(posts);
    }

    if (type === "latest") {
      allPosts.sort((a, b) => b.id - a.id);
      return res.json(allPosts.slice(0, 5));
    } else if (type === "popular") {
      let postCommentCounts = [];

      for (let post of allPosts) {
        const comments = await fetchPostComments(post.id);
        postCommentCounts.push({ ...post, commentCount: comments.length });
      }

      const maxComments = Math.max(...postCommentCounts.map((p) => p.commentCount));
      const topPosts = postCommentCounts.filter((p) => p.commentCount === maxComments);

      return res.json(topPosts);
    }

    res.status(400).json({ error: "Invalid type parameter" });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch posts" });
  }
}

module.exports = { getTopOrLatestPosts };