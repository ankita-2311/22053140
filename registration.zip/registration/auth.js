const axios = require("axios");

async function getAuthToken() {
  try {
    const response = await axios.post("http://20.244.56.144/evaluation-service/auth", {
      email: "22053140@kiit.ac.in",
      name: "Ankita Kumari",
      rollNo: "22053140",
      accessCode: "nwpwrZ",
      clientID: "da7720fa-739a-4c03-845c-a1e864754ff3",
      clientSecret: "zJHqFVnbYDVEVsMR"
    });

    console.log("Authorization Token:", response.data);
  } catch (error) {
    console.error("Failed to Get Token:", error.response ? error.response.data : error.message);
  }
}

getAuthToken();